package com.banking.fundtransfer;

import com.banking.fundtransfer.repository.AccountRepository;
import com.banking.fundtransfer.repository.PayeeRepository;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.banking.fundtransfer.entity.Account;
import com.banking.fundtransfer.entity.Payee;
import com.banking.fundtransfer.entity.Transaction;
import com.banking.fundtransfer.exceptions.PayeeListEmptyException;
import com.banking.fundtransfer.repository.TransactionRepository;
import com.banking.fundtransfer.service.AccountService;
import com.banking.fundtransfer.service.PayeeService;
import com.banking.fundtransfer.service.TransactionService;



@SpringBootTest
class FundTransferModuleApplicationTests 

{

	@Autowired 
	AccountService accServ;

	@Autowired TransactionService transactionService;
	
     
	@Autowired PayeeService payeeService;
	
	@Test
	void contextLoadsTest() 
	{
		
//		Account account=new Account();
//		account.setAccountNumber(38240309524L);
//		account.setAccountHolder("Deepesh Nagwanshi");
//		account.setBalance(500000);
//		account.setContactNumber(9009341350L);
//		account.setEmailId("nagwanshi.deepesh11@gmail.com");
//		account.setAccountType("Savings Account");
//		System.out.println("Account Added.......");
//		accServ.saveAccountService(account);
		
		Account account1=new Account();
		account1.setAccountNumber(36504787930L);
		account1.setAccountHolder("Rohit Verma");
		account1.setBalance(500000);
		account1.setContactNumber(7974149364L);
		account1.setEmailId("verma.rohit@gmail.com");
		account1.setAccountType("Savings Account");
//		System.out.println("Account1 Added.......");
		
		
		
		Payee payee2=new Payee();
		payee2.setBenificiaryName("Jayant Sachdeva");
		payee2.setBeneficairyAccountNumber(53033323270L);
		payee2.setBeneficairyIFSCCode("BARBOMAHIDP");
		payee2.setBeneficairyLimit(300000);
		payee2.setBeneficiaryBankName("BANK OF BARODA");
		payee2.setBeneficiaryBranchName("Mahidpur");
	//	payeeService.addPayeeService(payee2);
		
	
		
		
		Payee payee5=new Payee();
		payee5.setBenificiaryName("Ram Jain");
		payee5.setBeneficairyAccountNumber(530333271256L);
		payee5.setBeneficairyIFSCCode("UTIB0005831");
		payee5.setBeneficairyLimit(1000000);
		payee5.setBeneficiaryBankName("AXIS BANK");
		payee5.setBeneficiaryBranchName("Kharghar Sector 10");
	//	payeeService.addPayeeService(payee5);
		
		Set<Payee> newSet = new HashSet<Payee>() ;
		newSet.add(payee2);
		newSet.add(payee5);
		account1.setPayees(newSet);
		
		List<Transaction> txnSet= new ArrayList<Transaction>();
		Transaction txn = new Transaction();
	    txn.setAccount(account1);
	    txn.setCreditAmount(30000);
	    txn.setReferenceNumber("SBIN00305228251221");
	    String date="2022-06-27";
	      Date date1 = null;
	    txn.setTransactionDate(date1.valueOf(date));
	    txn.setUpdatedBalance(35000);
		txnSet.add(txn);
		account1.setTransactions(txnSet);
	     Assertions.assertTrue(account1!=null);
	      accServ.saveAccountService(account1);
	
	
	
	}
  
	@Test
	void contextPayeeTest()
	{
		Payee payee=new Payee();
		payee.setBenificiaryName("Prince Kumar Gupta");
		payee.setBeneficairyAccountNumber(1428554125541L);
		payee.setBeneficairyIFSCCode("ICIC0125315");
		payee.setBeneficairyLimit(1000000);
		payee.setBeneficiaryBankName("ICICI BANK");
		payee.setBeneficiaryBranchName("CBD Belapur");
		payeeService.addPayeeService(payee);
		
		
		Payee payee1=new Payee();
		payee1.setBenificiaryName("Piyush Gulane");
		payee1.setBeneficairyAccountNumber(53033323146L);
		payee1.setBeneficairyIFSCCode("HDFC000240");
		payee1.setBeneficairyLimit(5000000);
		payee1.setBeneficiaryBankName("HDFC BANK");
		payee1.setBeneficiaryBranchName("CBD Belapur");
		payeeService.addPayeeService(payee1);
		
		
		Payee payee2=new Payee();
		payee2.setBenificiaryName("Jayant Sachdeva");
		payee2.setBeneficairyAccountNumber(53033323270L);
		payee2.setBeneficairyIFSCCode("BARBOMAHIDP");
		payee2.setBeneficairyLimit(300000);
		payee2.setBeneficiaryBankName("BANK OF BARODA");
		payee2.setBeneficiaryBranchName("Mahidpur");
		payeeService.addPayeeService(payee2);
		
		
		Payee payee3=new Payee();
		payee3.setBenificiaryName("Stefan Raja");
		payee3.setBeneficairyAccountNumber(91130156114251L);
		payee3.setBeneficairyIFSCCode("BKID0009113");
		payee3.setBeneficairyLimit(200000);
		payee3.setBeneficiaryBankName("BANK OF INDIA");
		payee3.setBeneficiaryBranchName("SEA WOODS");
		payeeService.addPayeeService(payee3);
		
		
		
		Payee payee4=new Payee();
		payee4.setBenificiaryName("Tuhin Kumar ");
		payee4.setBeneficairyAccountNumber(5120052522111L);
		payee4.setBeneficairyIFSCCode("HDFC000241");
		payee4.setBeneficairyLimit(600000);
		payee4.setBeneficiaryBankName("HDFC BANK");
		payee4.setBeneficiaryBranchName("Nerul West");
		payeeService.addPayeeService(payee4);
		
		
		
		Payee payee5=new Payee();
		payee5.setBenificiaryName("Ram Jain");
		payee5.setBeneficairyAccountNumber(530333271256L);
		payee5.setBeneficairyIFSCCode("UTIB0005831");
		payee5.setBeneficairyLimit(1000000);
		payee5.setBeneficiaryBankName("AXIS BANK");
		payee5.setBeneficiaryBranchName("Kharghar Sector 10");
		payeeService.addPayeeService(payee5);
		
	}
	@Test
	void findAllPayee() throws PayeeListEmptyException
	{
		List<Payee> payeeList = new ArrayList<Payee>();
		
		payeeList  = (List<Payee>) payeeService.findAllPayeeService();
		for (Payee payee : payeeList) 
		{
			System.out.println("Beneficaiary_Name  : "+payee.getBenificiaryName());
			System.out.println("Beneficaiary Account_Number   : "+payee.getBeneficairyAccountNumber());
			System.out.println("Beneficairy_Bank_Name: "+payee.getBeneficiaryBankName());
			System.out.println("Beneficairy_Branch_Name  : "+payee.getBeneficiaryBranchName());
			System.out.println("IFSC CODE : "+payee.getBeneficairyIFSCCode());
			System.out.println("Limit: "+payee.getBeneficairyLimit());
			System.out.println("------------------------");
		}
		
	}
	
}
