package com.banking.fundtransfer;

import org.junit.jupiter.api.Test;

public class ServiceTesting {
	

}
