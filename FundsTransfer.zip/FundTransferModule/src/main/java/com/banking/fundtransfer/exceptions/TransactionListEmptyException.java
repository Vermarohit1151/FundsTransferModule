package com.banking.fundtransfer.exceptions;

public class TransactionListEmptyException extends Exception

{

	public TransactionListEmptyException(String message) 
	{
		super(message);
		// TODO Auto-generated constructor stub
	}

}
