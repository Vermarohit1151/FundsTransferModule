package com.banking.fundtransfer.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.banking.fundtransfer.entity.Transaction;
import com.banking.fundtransfer.exceptions.TransactionListEmptyException;
import com.banking.fundtransfer.exceptions.TransactionNotFoundException;

@Service
public interface TransactionService 

{
	public List<Transaction> findAllTransactionService() throws TransactionListEmptyException;

	public Transaction findTxnByIdService(int transactionId) throws TransactionNotFoundException;
	
	public Transaction saveTransaction(Transaction txn);
}
