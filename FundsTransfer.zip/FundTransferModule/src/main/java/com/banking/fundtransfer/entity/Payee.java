package com.banking.fundtransfer.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="Payee")
public class Payee 
{

	
@Id
@GeneratedValue
private int payeeId;

@Column(name="ContactNumber")
long ContactNumber;

@Column(name="email",length=20)
String Email;

public Set<Account> getAccounts() 
{
	return accounts;
}

public void setAccounts(Set<Account> accounts) 
{
	this.accounts = accounts;
}


@Column(name="Beneficiary_Name",length=20)
private String BenificiaryName;
@Column(name="Beneficairy_Account_Number")
private long BeneficairyAccountNumber;
@Column(name="Beneficairy_Bank_Name", length=15)
private String BeneficiaryBankName;
@Column (name="Beneficairy_Branch_Name",length=25)
private String BeneficiaryBranchName;
@Column(name="Beneficairy_IFSC_CODE", length=11)
private String BeneficairyIFSCCode;
@Column(name="Limit")
private long BeneficairyLimit;


@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
@JoinTable(
		name="account_payee_link_table",
		joinColumns = {@JoinColumn(name="payeeId")},
		inverseJoinColumns = {@JoinColumn(name="accountId")}
)
private Set<Account> accounts;


public long getContactNumber() {
	return ContactNumber;
}

public void setContactNumber(long contactNumber) {
	ContactNumber = contactNumber;
}

public String getEmail() {
	return Email;
}

public void setEmail(String email) {
	Email = email;
}

public String getBenificiaryName() 
{
	return BenificiaryName;
}

public void setBenificiaryName(String benificiaryName) 
{
	BenificiaryName = benificiaryName;
}

public Payee(){
	super();
}

public long getBeneficairyAccountNumber() {
	return BeneficairyAccountNumber;
}

public void setBeneficairyAccountNumber(long beneficairyAccountNumber) {
	BeneficairyAccountNumber = beneficairyAccountNumber;
}

public String getBeneficiaryBankName() {
	return BeneficiaryBankName;
}

public void setBeneficiaryBankName(String beneficiaryBankName) {
	BeneficiaryBankName = beneficiaryBankName;
}

public String getBeneficiaryBranchName() {
	return BeneficiaryBranchName;
}

public void setBeneficiaryBranchName(String beneficiaryBranchName) {
	BeneficiaryBranchName = beneficiaryBranchName;
}

public String getBeneficairyIFSCCode() {
	return BeneficairyIFSCCode;
}

public void setBeneficairyIFSCCode(String beneficairyIFSCCode) {
	BeneficairyIFSCCode = beneficairyIFSCCode;
}

public long getBeneficairyLimit() {
	return BeneficairyLimit;
}

public void setBeneficairyLimit(long beneficairyLimit) {
	BeneficairyLimit = beneficairyLimit;
}



}
