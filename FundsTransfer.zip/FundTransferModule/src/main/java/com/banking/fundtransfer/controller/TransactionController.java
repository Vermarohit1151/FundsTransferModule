package com.banking.fundtransfer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.banking.fundtransfer.entity.Transaction;
import com.banking.fundtransfer.service.TransactionService;



@CrossOrigin			//CORS
@RestController
@RequestMapping("/transaction")
public class TransactionController {
	@Autowired TransactionService transactionService;
	
	@PostMapping("/addTransaction")
	public ResponseEntity<Transaction> addFlight(@RequestBody Transaction txn)
	{
		ResponseEntity<Transaction> responseRef=null;
		Transaction newTxn = transactionService.saveTransaction(txn);
		responseRef = ResponseEntity.ok(newTxn);
		return responseRef;
	}
}
