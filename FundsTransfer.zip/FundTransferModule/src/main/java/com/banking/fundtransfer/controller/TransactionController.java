package com.banking.fundtransfer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.banking.fundtransfer.entity.Transaction;
import com.banking.fundtransfer.exceptions.TransactionNotFoundException;
import com.banking.fundtransfer.service.TransactionService;



@CrossOrigin			//CORS
@RestController
@RequestMapping("/transaction")
public class TransactionController {
	@Autowired TransactionService transactionService;
	
	@PostMapping("/addTransaction")
	public ResponseEntity<Transaction> addTransaction(@RequestBody Transaction txn)
	{
		ResponseEntity<Transaction> responseRef=null;
		Transaction newTxn = transactionService.saveTransaction(txn);
		responseRef = ResponseEntity.ok(newTxn);
		return responseRef;
	}
	
	@GetMapping("/getTransaction/{id}")
	public ResponseEntity<Transaction> getTransaction(@PathVariable ("id") int tId)
	{
		Transaction newTxn;
		ResponseEntity<Transaction> responseRef=null;
		try {
			newTxn = transactionService.findTxnByIdService(tId);
			responseRef = ResponseEntity.ok(newTxn);
		}
		catch (TransactionNotFoundException e) {
			  System.err.println(e);
		}
		 
		
		return responseRef;
	}
}
