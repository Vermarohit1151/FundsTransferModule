package com.banking.fundtransfer.serviceImpl;
import com.banking.fundtransfer.entity.Account;
import com.banking.fundtransfer.repository.*;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.banking.fundtransfer.service.AccountService;


@Service
public class AccountServiceImpl implements AccountService


{
@Autowired
AccountRepository accountRepository;


@Override
public Account saveAccountService(Account AccountObj)

{
	Account accountSaved =null;
	System.out.println("4 : Service Layer");
	accountSaved = accountRepository.save(AccountObj);
	System.out.println("In service layer after persist");
	
 return accountSaved;
}



@Override
public Account getAccountService(int cif) {
	Optional<Account> detailedAccount = accountRepository.findById(cif);
	return detailedAccount.get();
}

}

