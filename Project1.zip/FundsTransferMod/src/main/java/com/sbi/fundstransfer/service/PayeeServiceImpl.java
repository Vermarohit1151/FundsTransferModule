package com.sbi.fundstransfer.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.sbi.fundstransfer.repository.PayeeRepository;
import com.sbi.fundstransfer.exceptions.*;
import com.sbi.fundstransfer.pojo.Payee;


@Service
public class PayeeServiceImpl implements PayeeService
{
	@Autowired PayeeRepository payeeRepository;
	@Override
	public List<Payee> findAllPayeeService() throws PayeeListEmptyException{
		// TODO Auto-generated method stub
		List<Payee> payeeList = (List<Payee>) payeeRepository.findAll();
		if (payeeList.isEmpty()) {
			throw new PayeeListEmptyException("Payee List is empty! Please add a new payee first");
		}
		else {
			return payeeList;
		}
		
	}

	@Override
	public Payee findPayeeByIdService(int payeeId) throws PayeeNotFoundException {
		// TODO Auto-generated method stub
		Optional<Payee> thePayee = payeeRepository.findById(payeeId);
		if(thePayee.isPresent()) {
			return thePayee.get();
		}
		else {
			throw new PayeeNotFoundException("Payee not found for the given ID");
		}
		
	}

	@Override
	public Payee savePayeeService(Payee PayeeObject) {
		// TODO Auto-generated method stub
		Payee newPayee = payeeRepository.save(PayeeObject);
		return newPayee;
	}

	
	
	


}
