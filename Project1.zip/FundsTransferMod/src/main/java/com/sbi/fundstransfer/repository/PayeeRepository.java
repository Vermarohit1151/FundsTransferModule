package com.sbi.fundstransfer.repository;




import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.sbi.fundstransfer.pojo.Payee;


@Repository
public interface PayeeRepository extends CrudRepository<Payee, Integer>

{



}
