package com.sbi.fundstransfer.repository;



import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.sbi.fundstransfer.pojo.Transaction;


@Repository
public interface TransactionRepository extends CrudRepository<Transaction, Integer>

{



}
