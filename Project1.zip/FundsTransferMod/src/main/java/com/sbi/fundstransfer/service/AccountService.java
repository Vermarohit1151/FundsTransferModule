package com.sbi.fundstransfer.service;


import org.springframework.stereotype.Service;

import com.sbi.fundstransfer.pojo.Account;


@Service
public interface AccountService 

{

	
public Account saveAccountService(Account AccountObj);

} 


