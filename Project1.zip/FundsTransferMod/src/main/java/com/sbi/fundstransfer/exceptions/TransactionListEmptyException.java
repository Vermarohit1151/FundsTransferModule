package com.sbi.fundstransfer.exceptions;

public class TransactionListEmptyException extends Exception

{

	public TransactionListEmptyException(String message) 
	{
		super(message);
		// TODO Auto-generated constructor stub
	}

}
