package com.sbi.fundstransfer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FundsTransferModApplication {

	public static void main(String[] args) {
		SpringApplication.run(FundsTransferModApplication.class, args);
		System.out.println("Spring Boot Application Started");
	}

}
