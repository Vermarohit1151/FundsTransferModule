package com.sbi.fundstransfer.exceptions;

public class PayeeNotFoundException extends Exception

{

	public PayeeNotFoundException(String message) 
	{
		super(message);
		// TODO Auto-generated constructor stub
	}

}
