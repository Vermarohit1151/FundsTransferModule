package com.sbi.fundstransfer.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sbi.fundstransfer.pojo.*;
import com.sbi.fundstransfer.service.PayeeService;
import com.sbi.fundstransfer.ResponseStatus;
import com.sbi.fundstransfer.exceptions.*;



@CrossOrigin
@Controller
@RequestMapping("/payee")
public class PayeeController
{

	@Autowired 
	PayeeService payeeService;
	
	@PostMapping("/addpayee")
	public ResponseEntity<Payee> savePayee(@RequestBody Payee payee)

	{
		ResponseEntity<Payee> responseRef=null;
	    Payee payee1 = payeeService.savePayeeService(payee);
	    responseRef = ResponseEntity.ok(payee1);
		return responseRef;
		
	}
	
	@RequestMapping("/getPayee/{pid}")
	public ResponseEntity <Payee> getPayeeObject(@PathVariable("pid") int payeeId)
	{
		
		Payee payee = null;
		ResponseEntity responseRef=null;
		try {
			payee = payeeService.findPayeeByIdService(payeeId);
			responseRef = ResponseEntity.ok(payee);
			return responseRef;
		} 
		catch (Exception e) {
			//throw e;
			System.out.println("Payee list is empty ");
			ResponseStatus respStatus = new ResponseStatus();
			respStatus.setMessage(e.getMessage());
			responseRef = ResponseEntity.status(HttpStatus.NOT_FOUND).body(respStatus);
			//return responseRef;
		}
		return responseRef;
		
	}

	
	@GetMapping("/getAllPayee")
	public List<Payee> findAllPayee() {
		List <Payee> payeeList = new ArrayList<Payee>() ;
		try {
			payeeList = payeeService.findAllPayeeService();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return payeeList;
		 

	}	
}
