package com.sbi.fundstransfer.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.sbi.fundstransfer.pojo.Transaction;
import com.sbi.fundstransfer.repository.TransactionRepository;

import com.sbi.fundstransfer.exceptions.TransactionListEmptyException;
import com.sbi.fundstransfer.exceptions.TransactionNotFoundException;


@Service
public class TransactionServiceImpl implements TransactionService

{
	@Autowired
	TransactionRepository txnRepo;
	@Override
	public List<Transaction> findAllTransactionService() throws TransactionListEmptyException {
		
		List<Transaction> txnList = (List<Transaction>) txnRepo.findAll();
		if (txnList.isEmpty()) {
			throw new TransactionListEmptyException("No txns found for this user ID");
		}
		else {
			return txnList;
		}
		
	}

	@Override
	public Transaction findTxnByIdService(int transactionId) throws TransactionNotFoundException {
		Optional<Transaction> txn = txnRepo.findById(transactionId);
		if(txn.isPresent()) {
			return txn.get();
		}
		else {
			throw new TransactionNotFoundException("No such transaction exists");
		}
	}

	
	
	

}
