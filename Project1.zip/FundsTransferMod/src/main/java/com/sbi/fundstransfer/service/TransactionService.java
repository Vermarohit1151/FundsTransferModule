package com.sbi.fundstransfer.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sbi.fundstransfer.pojo.Transaction;
import com.sbi.fundstransfer.exceptions.*;

@Service
public interface TransactionService 

{
	public List<Transaction> findAllTransactionService() throws TransactionListEmptyException;

	public Transaction findTxnByIdService(int transactionId) throws TransactionNotFoundException;
}
