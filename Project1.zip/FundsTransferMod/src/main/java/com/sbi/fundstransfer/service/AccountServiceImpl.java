package com.sbi.fundstransfer.service;
import com.sbi.fundstransfer.pojo.Account;
import com.sbi.fundstransfer.repository.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.fundstransfer.service.AccountService;


@Service
public class AccountServiceImpl implements AccountService


{
@Autowired
AccountRepository accountRepository;







@Override
public Account saveAccountService(Account AccountObj) {

	Account accountSaved =null;
	System.out.println("4 : Service Layer");
	//Optional<Flight> flight = flighvoitRepository.findById(flightObj.getFlightNumber());
	
	accountSaved = accountRepository.save(accountSaved);
	
 return accountSaved;
}

}

