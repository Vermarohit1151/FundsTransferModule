package com.sbi.fundstransfer.service;

import java.util.List;

import org.springframework.stereotype.Service;

//import com.sbi.fundstransfer.pojo.Account;
import com.sbi.fundstransfer.pojo.Payee;
import com.sbi.fundstransfer.exceptions.*;

@Service
public interface PayeeService 
{

	
	public List<Payee> findAllPayeeService() throws PayeeListEmptyException;

	public Payee findPayeeByIdService(int payeeId) throws PayeeNotFoundException;
	
	public Payee savePayeeService(Payee PayeeObject);


}
